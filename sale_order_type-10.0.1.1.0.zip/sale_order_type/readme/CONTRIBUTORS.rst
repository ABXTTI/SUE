* Carlos Sánchez Cifuentes <csanchez@grupovermon.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Pedro M. Baeza <pedro.baeza@serviciosbaeza.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Daniel Campos <danielcampos@avanzosc.es>
* Ainara Galdona <ainaragaldona@avanzosc.es>
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Samuel Lefever <sam@niboo.be>
* Pierre Faniel <pierre@niboo.be>
* Simone Rubino <simone.rubino@agilebg.com>
