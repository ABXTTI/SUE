# -*- coding: utf-8 -*-
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import sale_order_type
from . import sale_order_type_rule
from . import sale_order
from . import res_partner
from . import account_invoice
